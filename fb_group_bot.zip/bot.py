import json
from fbchat import Client
from fbchat.models import Message

# Load cookies
with open("fbstate.json", "r") as f:
    fbstate = json.load(f)

# Load responses
with open("responses.json", "r", encoding="utf-8") as f:
    responses = json.load(f)

class Bot(Client):
    def onMessage(self, author_id, message_object, thread_id, thread_type, **kwargs):
        msg = message_object.text.lower()
        if author_id != self.uid:
            for trigger, reply in responses.items():
                if trigger in msg:
                    self.send(Message(text=reply), thread_id=thread_id, thread_type=thread_type)

client = Bot(None, None, session_cookies=fbstate)
client.listen()
